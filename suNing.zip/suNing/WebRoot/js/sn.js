var t = n = 0, count;
$(document).ready(
		function() {
			$(".xlk").bind("mouseover", function() {
				$(".content").show();
			});
			// ���P��ǩ�л�������
			$('.select > p').on('mouseover', function(event) {
				$('.select').toggleClass('open');
			});
			// �����������������ط�������������
			$(document).on('click', function() {
				$('.select').removeClass('open');
				$(".content").hide();
			});
			$('#tail a').hover(function() {
				$(this).css('background-color', '#B81C27');
			}, function() {
				$(this).css('background-color', '#252526');
			});
			// ��涯��

			// ��ȡͼƬ��ǩ����
			count = $("#banner_list a").length;
			// ���˵�һ��ͼ������
			$("#banner_list a:not(:first-child)").hide();
			// ��������1234��ť���л�ͼƬ
			$("#banner li").click(
					function() {
						var i = $(this).text() - 1;
						n = i;
						if (i >= count)
							return;
						// ���뵭��Ч��
						$("#banner_list a").filter(":visible").fadeOut(500)
								.parent().children().eq(i).fadeIn(1000);
						// ��Ӧ���
						$(this).toggleClass("on");
						// �л���ť��ʱ������һ����ť�ع�ԭ������ʽ
						$(this).siblings().removeAttr("class");
					});
			// top������a��ǩ��ͣʱ��ɫ
			$("#top a").hover(function() {
				$(this).css("color", "#FF6600");
			}, function() {
				$(this).css("color", "#666666");
			});
			// top��ͣ����
			$(".content").hide();
			$(".wzdhxlk").hide();
			$(".sjrzxlk").hide();
			$(".khfwxlk").hide();
			$(".wdygxlk").hide();
			$(".gwcxlk").hide();
			$(".sjsnxlk").hide();
			$(".qjdxlk").hide();
			$(".showWzdhxlk").bind("mouseover", function() {
				$(".wzdhxlk").show();
			});
			$(".wzdhxlk").bind("mouseout", function() {
				$(".wzdhxlk").hide();
			});
			$(".showSjrzxlk").bind("mouseover", function() {
				$(".sjrzxlk").show();
			});
			$(".sjrzxlk").bind("mouseout", function() {
				$(".sjrzxlk").hide();
			});
			$(".showKhfwxlk").bind("mouseover", function() {
				$(".khfwxlk").show();
			});
			$(".khfwxlk").bind("mouseout", function() {
				$(".khfwxlk").hide();
			});
			$("#top>div>a:nth-child(4)").bind("mouseover", function() {
				$(".wdygxlk").show();
			});
			$(".wdygxlk").bind("mouseout", function() {
				$(".wdygxlk").hide();
			});
			$("#top>div>a:nth-child(7)").bind("mouseover", function() {
				$(".gwcxlk").show();
			});
			$(".gwcxlk").bind("mouseout", function() {
				$(".gwcxlk").hide();
			});
			$("#top>div>a:last-child").bind("mouseover", function() {
				$(".sjsnxlk").show();
			});
			$(".sjsnxlk").bind("mouseout", function() {
				$(".sjsnxlk").hide();
			});
			$(".showQjdxlk").bind("mouseover", function() {
				$(".qjdxlk").show();
			});
			$(".qjdxlk").bind("mouseout", function() {
				$(".qjdxlk").hide();
			});
		});
t = setInterval("showAuto()", 4000);
$("#banner").hover(function() {
	clearInterval(t);
}, function() {
	t = setInterval("showAuto()", 4000);
});
// �Զ��ֲ�
function showAuto() {
	n = n >= (count - 1) ? 0 : ++n;
	$("#banner li").eq(n).trigger('click');
}