$(function() {
	$("#myTaobao").hide();
	$("#myTaobao2").hide();
	$("#myTaobao3").hide();
	$("#myTaobao4").hide();
	$("#myTaobao5").hide();
	$("#top>div>a:nth-child(1)").hover(function() {
		$(this).css("color", "red").css("text-decoration", "underline");
		$("#myTaobao").show();
	}, function() {
		$(this).css("color", "white").css("text-decoration", "none");
		$("#myTaobao").hide();
	});
	$("#myTaobao").hover(function() {
		$(this).css("color", "red").css("text-decoration", "underline");
		$("#myTaobao").show();
	}, function() {
		$(this).css("color", "white").css("text-decoration", "none");
		$("#myTaobao").hide();
	});
	$("#top>div>a:nth-child(2)").hover(function() {
		$(this).css("color", "yellow");
	}, function() {
		$(this).css("color", "white");
	});
	$("#myTaobao2").hover(function() {
		$(this).css("color", "red").css("text-decoration", "underline");
		$("#myTaobao2").show();
	}, function() {
		$(this).css("color", "white").css("text-decoration", "none");
		$("#myTaobao2").hide();
	});
	$("#top>div>a:nth-child(3)").hover(function() {
		$(this).css("color", "red").css("text-decoration", "underline");
		$("#myTaobao2").show();
	}, function() {
		$(this).css("color", "white").css("text-decoration", "none");
		$("#myTaobao2").hide();
	});
	$("#top>div>a:nth-child(4)").hover(function() {
		$(this).css("color", "yellow");
		$("#myTaobao3").show();
	}, function() {
		$(this).css("color", "white");
		$("#myTaobao3").hide();
	});
	$("#top>div>a:nth-child(5)").hover(function() {
		$(this).css("color", "yellow");

	}, function() {
		$(this).css("color", "white");

	});
	$("#top>div>a:nth-child(6)").hover(function() {
		$(this).css("color", "yellow");
		$("#myTaobao4").show();
	}, function() {
		$(this).css("color", "white");
		$("#myTaobao4").hide();
	});
	$("#top>div>a:nth-child(7)").hover(function() {
		$(this).css("color", "yellow");
		$("#myTaobao5").show();
	}, function() {
		$(this).css("color", "white");
		$("#myTaobao5").hide();
	});
});